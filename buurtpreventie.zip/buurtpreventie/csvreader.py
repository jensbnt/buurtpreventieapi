import csv

from apiwriter import writeGemeente

with open('zipcodes_alpha_nl.csv') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=';')
    line_count = 0
    for row in csv_reader:
        if line_count != 0:
            print(f'POSTING: {row[0]} : {row[2]}')
            res = writeGemeente(row[0], row[2])
            print(res)
        line_count += 1
    print(f'Processed {line_count} lines.')