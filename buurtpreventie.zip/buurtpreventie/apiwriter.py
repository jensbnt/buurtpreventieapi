import requests
import json
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

BUURPREVENTIE_API_URL = "https://localhost:44323/api/gemeente"

def writeGemeente(postcode, naam):
    gemeente = {}
    gemeente["postcode"] = postcode
    gemeente["naam"] = naam

    response = requests.post(BUURPREVENTIE_API_URL, json=gemeente, verify=False)
    json_response = response.json()

    return json_response
